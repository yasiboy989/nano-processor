import re

# Function to convert register name to 3-bit binary
def reg_to_bin(reg):
    reg_num = int(reg[1])  # Assuming register names like R0, R1, etc.
    return format(reg_num, '03b')

# Function to convert immediate or address value to binary
def imm_to_bin(val, bits):
    return format(int(val), f'0{bits}b')

# Function to parse a single assembly instruction
def parse_instruction(line):
    tokens = line.strip().replace(',', ' ').split()
    if not tokens:
        return None

    opcode = tokens[0].upper()

    if opcode == 'MOVI':
        reg_bin = reg_to_bin(tokens[1])
        imm_bin = imm_to_bin(tokens[2], 4)
        return '10' + reg_bin + '000' + imm_bin

    elif opcode == 'ADD':
        rega_bin = reg_to_bin(tokens[1])
        regb_bin = reg_to_bin(tokens[2])
        return '00' + rega_bin + regb_bin + '0000'

    elif opcode == 'NEG':
        reg_bin = reg_to_bin(tokens[1])
        return '01' + reg_bin + '0000000'

    elif opcode == 'JZR':
        reg_bin = reg_to_bin(tokens[1])
        addr_bin = imm_to_bin(tokens[2], 3)
        return '11' + reg_bin + '000' + addr_bin

    else:
        raise ValueError(f"Unsupported instruction: {opcode}")

# Main function
def asm_to_vhdl_rom_segment(input_filename):
    machine_codes = []

    with open(input_filename, 'r') as file:
        lines = file.readlines()

    for line in lines:
        # Ignore comments and empty lines
        clean_line = re.sub(r';.*', '', line)  # Remove comments
        if clean_line.strip() == '':
            continue

        try:
            code = parse_instruction(clean_line)
            if code:
                machine_codes.append(code)
        except ValueError as e:
            print(f"Error: {e}")
            continue

    # Ensure exactly 8 instructions
    while len(machine_codes) < 8:
        machine_codes.append("000000000000")  # Padding with blank/NOP

    # Generate only the ROM initialization block
    print("signal ROM : rom_array := (")
    for idx, code in enumerate(machine_codes):
        comma = ',' if idx != len(machine_codes) - 1 else ''
        print(f"    {idx} => \"{code}\"{comma}")
    print(");")

# Example usage
if __name__ == "__main__":
    asm_file = input("Enter the input .ASM filename: ")
    asm_to_vhdl_rom_segment(asm_file)
